//
//  ViewController.h
//  Searchbar
//
//  Created by Suresh Soni on 7/25/17.
//  Copyright © 2017 Suresh Soni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSMutableArray *filteredContentList;

}
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (strong, nonatomic) IBOutlet UISearchController *searchBarController;

@end

