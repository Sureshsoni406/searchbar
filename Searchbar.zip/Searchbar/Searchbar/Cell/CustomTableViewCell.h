//
//  CustomTableViewCell.h
//  FontTableView
//
//  Created by Suresh Soni on 7/25/17.
//  Copyright © 2017 Suresh Soni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *quoteLabel;

@end
