//
//  ViewController.m
//  Searchbar
//
//  Created by Suresh Soni on 7/25/17.
//  Copyright © 2017 Suresh Soni. All rights reserved.
//

#import "ViewController.h"
#import "CustomTableViewCell.h"
#import "NSMutableAttributedString+Color.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>
{
    NSMutableArray *Country_Array;
    BOOL isSearching;

}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) CustomTableViewCell *customCell;

@end

@implementation ViewController
@synthesize searchBar;
@synthesize searchBarController;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.tableView.delegate = self;
    self.tableView.dataSource = self;



    Country_Array = [@[@"india",@"New Zealand",@"Canada",@"Australia",@"Italy",@"United States",@"France",@"Spain",@"Ireland",@"United States",@" United Kingdom",@"Netherlands",@"Sweden",@"Brazil",@"China",@"Japan",@"Argentina",@"Greece",@"Singapore",@"Austria",@"Luxembourg",@"Germany",@"Portugal",@"Denmark",] mutableCopy];

    searchBar.enablesReturnKeyAutomatically = NO;

}
- (void)viewDidUnload {
    self.tableView=nil;
    [self setSearchBar:nil];
    [self setSearchBarController:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (isSearching) {
        return [filteredContentList count];
    }
    else {
        return [Country_Array count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    CustomTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"CustomCell"];
    if (indexPath.row % 2) {
        cell.backgroundColor = [[UIColor alloc]initWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1];
    } else {
        cell.backgroundColor = [[UIColor alloc]initWithRed:204/255.0 green:232.0/255.0 blue:250.0/255.0 alpha:1];

    }

    cell.quoteLabel.text = Country_Array[indexPath.row];


    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    if (isSearching) {
        //        cell.textLabel.text = [filteredContentList objectAtIndex:indexPath.row];

        NSString *str_color=[filteredContentList objectAtIndex:indexPath.row];
        NSString *str_cname=searchBar.text;


        NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:str_color];
        [string setColorForText:str_cname withColor:[UIColor redColor]];
        cell.quoteLabel.attributedText = string;

    }
    else {
        NSString *str_color=Country_Array[indexPath.row];
        NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:str_color];
        cell.quoteLabel.attributedText = string;
    }

   
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 200;
}

- (void)searchTableList {
    filteredContentList = [[NSMutableArray alloc] init];

    NSString *searchString = searchBar.text;
    NSMutableArray *rows = [NSMutableArray array];

    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains[cd] %@",searchString];
    rows = [NSMutableArray arrayWithArray:[Country_Array filteredArrayUsingPredicate:predicate]];

    NSLog(@"rows = %@",rows);

    for (NSString *tempStr in rows) {
        [filteredContentList addObject:tempStr];
        NSUInteger index = [Country_Array indexOfObject:tempStr];
        NSLog(@"index = = %lu",(unsigned long)index);
    }

}
#pragma mark - Search Implementation

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;

}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    NSLog(@"Text change - %d",isSearching);

    //Remove all objects first.
    [filteredContentList removeAllObjects];

    if([searchText length] != 0) {
        isSearching = YES;
        [self searchTableList];
    }
    else {
        isSearching = NO;
    }
    [self.tableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Cancel clicked");

}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    [self.searchBar resignFirstResponder];

    [self searchTableList];

}

-(BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    return YES;
}



@end
